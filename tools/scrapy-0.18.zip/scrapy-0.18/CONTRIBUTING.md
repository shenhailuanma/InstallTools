The guidelines for contributing are available here:
http://doc.scrapy.org/en/latest/contributing.html
